# 👋 Hey there, I'm Nikhilesh Swain

🎯 **Founder of Growthinc**  
Helping **B2B SaaS brands** scale through high-performance **ads, SEO, funnels**, and design.

---

### 🚀 What I Do

- 🔍 SEO & Web Strategy
- 📊 Performance Marketing (Meta Ads, Google Ads)
- 🎨 Funnel + Landing Page Development
- 📈 Lead Generation Campaigns
- 🧠 Brand Identity & Visual Design

---

### 📫 Let's Connect

- 📧 Email: [nikhileshswain5@gmail.com](mailto:nikhileshswain5@gmail.com)
- 💼 LinkedIn: [linkedin.com/in/nikhilesh-swain-13a332370](https://www.linkedin.com/in/nikhilesh-swain-13a332370)

---

### 🌱 About Growthinc

> *We don’t just market—we build.*  
From strategy to execution, we help brands reach the right audience, drive sales, and scale with impact.

---

![Growthinc Logo](https://github.com/nikhileshswain/nikhileshswain/raw/main/logo.png)
